const pros=[
      {name:'Ravi Kumar',trade:'Plumbing',emoji:'👨🏽‍🔧',rating:'4.9',reviews:128,years:'8 years experience',price:'₹499',className:'plumbing',image:'https://images.unsplash.com/photo-1749532125405-70950966b0e5?auto=format&fit=crop&w=900&q=80',keywords:'leak tap drain pipe bathroom water'},
      {name:'BrightLine Electric',trade:'Electrical',emoji:'👩🏻‍🔧',rating:'4.8',reviews:96,years:'6 years experience',price:'₹399',className:'electrical',image:'https://images.unsplash.com/photo-1741388222137-c0d3007ec173?auto=format&fit=crop&w=900&q=80',keywords:'switch light fan wiring electrician'},
      {name:'Oak & Nail Studio',trade:'Carpentry',emoji:'🧑🏽‍🔨',rating:'4.9',reviews:74,years:'10 years experience',price:'₹599',className:'carpentry',keywords:'wood furniture shelf door carpenter'},
      {name:'NeatNest Home Care',trade:'Cleaning',emoji:'🧹',rating:'4.7',reviews:152,years:'5 years experience',price:'₹799',className:'cleaning',keywords:'cleaning deep clean home kitchen'},
      {name:'ColorKind Painters',trade:'Painting',emoji:'🧑🏻‍🎨',rating:'4.8',reviews:62,years:'7 years experience',price:'₹999',className:'painting',image:'https://images.unsplash.com/photo-1679018179962-06922435f6bc?auto=format&fit=crop&w=900&q=80',keywords:'paint wall room touch up painter'},
      {name:'FixRight Appliances',trade:'Appliance repair',emoji:'🧰',rating:'4.8',reviews:88,years:'9 years experience',price:'₹499',className:'appliance',keywords:'washing machine fridge appliance repair'},
      {name:'CoolCare AC Service',trade:'AC service',emoji:'🧑🏾‍🔧',rating:'4.9',reviews:113,years:'7 years experience',price:'₹599',className:'ac',keywords:'air conditioner ac cooling service'}
    ];
    let activeCategory='All', query='';
    const grid=document.getElementById('providerGrid'), empty=document.getElementById('emptyState');
    function render(){const list=pros.filter(p=>(activeCategory==='All'||p.trade===activeCategory)&&(`${p.name} ${p.trade} ${p.keywords}`.toLowerCase().includes(query.toLowerCase())));grid.innerHTML=list.map((p,i)=>`<article class="provider"><div class="provider-image ${p.className}"><span class="verified">Sample profile</span>${p.image?`<img class="service-photo" src="${p.image}" alt="${p.trade} professional at work" loading="lazy">`:`<span class="emoji">${p.emoji}</span>`}</div><div class="provider-body"><div class="provider-title"><div><h3>${p.name}</h3><div class="trade">${p.trade} professional · ${p.years}</div></div><div class="rating"><span>★</span> ${p.rating} <small>(${p.reviews})</small></div></div><div class="provider-info"><span>Indicative starting price</span><span class="price">${p.price} <small>/ visit</small></span></div><div class="provider-actions"><a class="details-link" href="#how">View service details ↗</a><button class="book-btn" data-index="${pros.indexOf(p)}">Request a visit</button></div></div></article>`).join('');empty.style.display=list.length?'none':'block';grid.style.display=list.length?'grid':'none';document.getElementById('providerHeading').textContent=activeCategory==='All'?(query?`Search results for “${query}”`:'Local pros to get you started'):`${activeCategory} professionals`;
      grid.querySelectorAll('.book-btn').forEach(b=>b.addEventListener('click',()=>openBooking(pros[Number(b.dataset.index)])));}
    document.querySelectorAll('.cat').forEach(b=>b.addEventListener('click',()=>{document.querySelector('.cat.active').classList.remove('active');b.classList.add('active');activeCategory=b.dataset.category;render();document.getElementById('pros').scrollIntoView({behavior:'smooth'});}));
    document.getElementById('searchForm').addEventListener('submit',e=>{e.preventDefault();query=document.getElementById('searchInput').value.trim();activeCategory='All';document.querySelector('.cat.active').classList.remove('active');document.querySelector('[data-category="All"]').classList.add('active');render();document.getElementById('pros').scrollIntoView({behavior:'smooth'});});
    document.getElementById('searchInput').addEventListener('input',e=>{if(!e.target.value){query='';render();}});
    const modal=document.getElementById('bookingModal');let chosen=null;let bookingPrefill=null;
    function openBooking(p){closeHelper();chosen=p;document.getElementById('selectedPro').innerHTML=`<div class="selected-avatar" style="background:${getComputedStyle(document.querySelector('.provider-image.'+p.className)).backgroundColor}">${p.emoji}</div><div><strong>${p.name}</strong><span>${p.trade} · ★ ${p.rating} · Indicative price from ${p.price}</span></div>`;document.getElementById('bookingForm').reset();document.getElementById('summary').style.display='none';document.getElementById('bookingForm').style.display='block';const d=new Date();d.setMinutes(d.getMinutes()-d.getTimezoneOffset());document.getElementById('visitDate').min=d.toISOString().slice(0,10);if(bookingPrefill){document.getElementById('address').value=bookingPrefill.address;document.getElementById('jobDetails').value=bookingPrefill.jobDetails;document.getElementById('visitDate').value=bookingPrefill.visitDate;document.getElementById('visitTime').value=bookingPrefill.visitTime;bookingPrefill=null;}modal.classList.add('open');document.getElementById('customerName').focus();}
    function closeBooking(){modal.classList.remove('open')}document.getElementById('closeModal').addEventListener('click',closeBooking);modal.addEventListener('click',e=>{if(e.target===modal)closeBooking();});document.addEventListener('keydown',e=>{if(e.key==='Escape')closeBooking();});
    document.getElementById('bookingForm').addEventListener('submit',e=>{e.preventDefault();const f=new FormData(e.target);const date=new Date(f.get('visitDate')+'T00:00:00').toLocaleDateString(undefined,{year:'numeric',month:'long',day:'numeric'});document.getElementById('summaryText').innerHTML=`<b>Customer:</b> ${escapeHtml(f.get('customerName'))} · ${escapeHtml(f.get('customerPhone'))}<br><b>Service:</b> ${chosen.trade}<br><b>Professional:</b> ${chosen.name}<br><b>Starting price:</b> ${chosen.price} (indicative; final cost depends on the job)<br><b>Location:</b> ${escapeHtml(f.get('address'))}<br><b>Preferred visit:</b> ${date}, ${escapeHtml(f.get('visitTime'))}<br><b>Job:</b> ${escapeHtml(f.get('jobDetails'))}`;document.getElementById('bookingForm').style.display='none';document.getElementById('summary').style.display='block';});
    function escapeHtml(s){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}render();

    const helperLauncher=document.getElementById('helperLauncher');
    const helperPanel=document.getElementById('helperPanel');
    const helperMessages=document.getElementById('helperMessages');
    const helperInput=document.getElementById('helperInput');
    let helperStep='service';
    let helperData={};

    function resetHelper(){
      helperStep='service';helperData={};helperInput.disabled=false;helperInput.placeholder='Type your answer…';helperMessages.replaceChildren();
      addChatMessage('Hello! I can help you find a service and prepare a visit request. What do you need help with?');
      addQuickOptions(['Plumbing','Electrical','Cleaning','Carpentry','Painting','Not sure yet'],choice=>choice==='Not sure yet'?beginService('not sure'):beginService(choice));
    }
    function openHelper(){if(helperStep==='done')resetHelper();helperPanel.hidden=false;helperLauncher.setAttribute('aria-expanded','true');helperInput.focus();}
    function closeHelper(){helperPanel.hidden=true;helperLauncher.setAttribute('aria-expanded','false');}
    helperLauncher.addEventListener('click',()=>helperPanel.hidden?openHelper():closeHelper());
    document.getElementById('helperClose').addEventListener('click',closeHelper);

    function addChatMessage(text,who='bot'){
      const message=document.createElement('div');
      message.className=`chat-message ${who==='user'?'user-message':'bot-message'}`;
      message.textContent=text;
      helperMessages.append(message);
      helperMessages.scrollTop=helperMessages.scrollHeight;
      return message;
    }
    function removeServiceOptions(){const options=document.getElementById('serviceOptions');if(options)options.remove();}
    function addQuickOptions(labels,callback){
      const group=document.createElement('div');group.className='quick-options';
      labels.forEach(label=>{const button=document.createElement('button');button.type='button';button.textContent=label;button.addEventListener('click',()=>{group.remove();callback(label);});group.append(button);});
      helperMessages.append(group);helperMessages.scrollTop=helperMessages.scrollHeight;
    }
    function findService(value){
      const text=value.toLowerCase();
      const aliases={plumbing:['plumb','tap','leak','pipe','drain'],electrical:['electric','wiring','switch','light','fan'],carpentry:['carpent','wood','furniture','shelf','door'],cleaning:['clean','wash','dust'],painting:['paint','wall'], 'appliance repair':['appliance','fridge','washing machine','repair machine'], 'ac service':['ac','air condition','cooling']};
      return pros.find(pro=>pro.trade.toLowerCase()===text||aliases[pro.trade.toLowerCase()]?.some(word=>text.includes(word))||pro.keywords.split(' ').some(word=>word.length>3&&text.includes(word)))?.trade||null;
    }
    function beginService(value,showUser=true){
      removeServiceOptions();
      if(showUser)addChatMessage(value,'user');
      const selected=findService(value);
      if(!selected){
        helperStep='service';addChatMessage('I can help with plumbing, electrical work, cleaning, carpentry, painting, appliance repair, or AC service. Which one sounds closest?');
        addQuickOptions(['Plumbing','Electrical','Cleaning','Carpentry','Painting','Appliance repair','AC service'],choice=>beginService(choice));return;
      }
      helperData={...helperData,service:selected};
      if(helperData.location){helperStep='issue';addChatMessage(`Okay, let's look for ${selected.toLowerCase()} help near ${helperData.location}. What needs to be fixed or done?`);helperInput.placeholder='Describe the job…';helperInput.focus();return;}
      helperStep='location';addChatMessage(`Okay, let's look for ${selected.toLowerCase()} help. What village or town are you in? You can add a nearby landmark too.`);
      helperInput.placeholder='Type your village or town…';helperInput.focus();
    }
    function askForDate(){
      helperStep='date';addChatMessage('When would you prefer a visit? Choose a date below.');
      const box=document.createElement('div');box.className='date-prompt';
      const date=document.createElement('input');date.type='date';date.setAttribute('aria-label','Choose a preferred visit date');
      const localNow=new Date();localNow.setMinutes(localNow.getMinutes()-localNow.getTimezoneOffset());date.min=localNow.toISOString().slice(0,10);
      const button=document.createElement('button');button.type='button';button.textContent='Continue';
      button.addEventListener('click',()=>{if(!date.value){date.reportValidity();return;}helperData.date=date.value;box.remove();addChatMessage(new Date(`${date.value}T00:00:00`).toLocaleDateString(undefined,{month:'long',day:'numeric',year:'numeric'}),'user');helperStep='time';addChatMessage('What time of day works best?');addQuickOptions(['Morning','Afternoon','Evening'],chooseTime);});
      box.append(date,button);helperMessages.append(box);helperMessages.scrollTop=helperMessages.scrollHeight;
    }
    function chooseTime(value){
      helperData.time=value;helperStep='done';addChatMessage(value,'user');
      const dateLabel=new Date(`${helperData.date}T00:00:00`).toLocaleDateString(undefined,{month:'long',day:'numeric'});
      addChatMessage(`Here is your request so far: ${helperData.service} in ${helperData.location}, for ${helperData.issue}. Preferred visit: ${dateLabel}, ${value.toLowerCase()}.`);
      const next=document.createElement('div');next.className='chat-next';
      const note=document.createElement('p');note.textContent='Next, compare a local professional and add your contact details.';
      const button=document.createElement('button');button.type='button';button.className='chat-match-button';button.textContent='See pros for this service →';
      button.addEventListener('click',()=>{
        const catButton=document.querySelector(`[data-category="${helperData.service}"]`);
        if(document.querySelector('.cat.active'))document.querySelector('.cat.active').classList.remove('active');
        if(catButton)catButton.classList.add('active');
        activeCategory=helperData.service;query='';render();
        const timeMap={Morning:'Morning (8 am–12 pm)',Afternoon:'Afternoon (12 pm–4 pm)',Evening:'Evening (4 pm–8 pm)'};
        bookingPrefill={address:helperData.location,jobDetails:helperData.issue,visitDate:helperData.date,visitTime:timeMap[helperData.time]};
        closeHelper();document.getElementById('pros').scrollIntoView({behavior:'smooth'});
      });
      next.append(note,button);helperMessages.append(next);helperMessages.scrollTop=helperMessages.scrollHeight;
      helperInput.disabled=true;helperInput.placeholder='Request prepared';
    }
    function handleHelperInput(value){
      const text=value.trim();if(!text)return;
      if(helperStep==='service'){beginService(text);return;}
      if(helperStep==='location-first'){addChatMessage(text,'user');helperData={location:text};helperStep='service';addChatMessage('Thanks. What kind of home service do you need?');addQuickOptions(['Plumbing','Electrical','Cleaning','Carpentry','Painting','Appliance repair','AC service'],choice=>beginService(choice));helperInput.placeholder='Or type the service…';return;}
      addChatMessage(text,'user');
      if(helperStep==='location'){
        helperData.location=text;helperStep='issue';addChatMessage('What needs to be fixed or done? A short description is fine.');helperInput.placeholder='Describe the job…';
      }else if(helperStep==='issue'){
        helperData.issue=text;askForDate();helperInput.placeholder='';
      }else if(helperStep==='date'){
        addChatMessage('Please pick a date using the calendar control above.');
      }else if(helperStep==='done'){
        addChatMessage('Your request summary is ready. Choose “See matching pros” when you want to continue.');
      }
    }
    document.getElementById('serviceOptions').querySelectorAll('button').forEach(button=>button.addEventListener('click',()=>{
      if(button.dataset.service==='Not sure'){removeServiceOptions();addChatMessage('That’s okay. Choose the closest service, or type a few words about the job.','user');addQuickOptions(['Plumbing','Electrical','Cleaning','Carpentry','Painting','Appliance repair','AC service'],choice=>beginService(choice));return;}
      beginService(button.dataset.service);
    }));
    document.getElementById('locationButton').addEventListener('click',()=>{
      if(helperStep==='done')resetHelper();
      openHelper();helperMessages.replaceChildren();helperData={};helperStep='location-first';
      addChatMessage('Tell me your village or town. You can include a nearby landmark.');
      helperInput.placeholder='Type your village or town…';helperInput.focus();
    });
    document.getElementById('helperForm').addEventListener('submit',event=>{event.preventDefault();handleHelperInput(helperInput.value);helperInput.value='';});
