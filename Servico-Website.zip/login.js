const form = document.getElementById('authForm');
const status = document.getElementById('authStatus');
const modeButton = document.getElementById('switchMode');
const submitButton = document.getElementById('submitButton');
const nameField = document.getElementById('nameField');
const businessField = document.getElementById('businessField');
const fullName = document.getElementById('fullName');
const businessName = document.getElementById('businessName');
const password = document.getElementById('password');

let role = 'customer';
let isSignUp = false;

function updateForm() {
  nameField.hidden = !isSignUp;
  businessField.hidden = !(isSignUp && role === 'professional');
  fullName.required = isSignUp;
  businessName.required = isSignUp && role === 'professional';
  password.autocomplete = isSignUp ? 'new-password' : 'current-password';
  document.getElementById('authTitle').innerHTML = isSignUp
    ? 'Let’s get your<br><em>home sorted.</em>'
    : 'Good to have<br>you <em>back.</em>';
  submitButton.innerHTML = isSignUp ? 'Create my account <span>→</span>' : 'Log in <span>→</span>';
  document.getElementById('switchPrompt').textContent = isSignUp ? 'Already have an account?' : 'New to Servico?';
  modeButton.textContent = isSignUp ? 'Log in' : 'Create an account';
  status.classList.remove('visible');
}

document.querySelectorAll('.role-option').forEach(button => {
  button.addEventListener('click', () => {
    role = button.dataset.role;
    document.querySelectorAll('.role-option').forEach(option => {
      const selected = option === button;
      option.classList.toggle('selected', selected);
      option.setAttribute('aria-pressed', String(selected));
    });
    updateForm();
  });
});

modeButton.addEventListener('click', () => {
  isSignUp = !isSignUp;
  updateForm();
});

document.getElementById('togglePassword').addEventListener('click', event => {
  const show = password.type === 'password';
  password.type = show ? 'text' : 'password';
  event.currentTarget.textContent = show ? 'Hide' : 'Show';
  event.currentTarget.setAttribute('aria-label', show ? 'Hide password' : 'Show password');
});

document.getElementById('forgotPassword').addEventListener('click', () => {
  status.textContent = 'Password recovery will be available when Servico is connected to an account service.';
  status.classList.add('visible');
});

form.addEventListener('submit', event => {
  event.preventDefault();
  status.classList.remove('visible');
  if (!form.checkValidity()) {
    form.reportValidity();
    return;
  }

  const action = isSignUp ? 'Account creation' : 'Sign-in';
  status.textContent = `${action} is a prototype preview. Your details were not sent or saved because account authentication is not connected yet.`;
  status.classList.add('visible');
});

document.getElementById('year').textContent = new Date().getFullYear();
